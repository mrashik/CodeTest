package codechallenge.operation;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class LowerCaseOperationTest {

    @InjectMocks
    LowerCaseOperation lowerCaseOperation;

    @Test
    public void testToLowerCase() {
        Assert.assertEquals(lowerCaseOperation.action("THIS IS IT"), "this is it");
    }
}
