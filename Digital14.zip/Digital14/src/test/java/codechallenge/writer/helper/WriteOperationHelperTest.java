package codechallenge.writer.helper;

import codechallenge.enums.WriteOperation;
import codechallenge.writer.impl.WriteOperationHelper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
public class WriteOperationHelperTest {

    @Test
    public void testApplyOperation() {
        Assert.assertEquals(WriteOperationHelper.applyOperation("This is is it", WriteOperation.DUPLICATE_REMOVER, WriteOperation.TO_LOWER_CASE), "this is it");
    }
}
