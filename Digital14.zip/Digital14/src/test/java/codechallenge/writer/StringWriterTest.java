package codechallenge.writer;

import codechallenge.enums.WriteOperation;
import codechallenge.writer.impl.StringWriter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class StringWriterTest {

    @InjectMocks
    StringWriter stringWriter;

    @Test
    public void testPrintStringAfterWrite() {
        stringWriter.write("This is is it", WriteOperation.DUPLICATE_REMOVER, WriteOperation.TO_UPPER_CASE);
        stringWriter.print();
    }

    @Test
    public void testWriteStringAfterClose() {
        stringWriter.close();
        stringWriter.write("This is is it", WriteOperation.DUPLICATE_REMOVER, WriteOperation.TO_UPPER_CASE);
        stringWriter.print();
    }
}
