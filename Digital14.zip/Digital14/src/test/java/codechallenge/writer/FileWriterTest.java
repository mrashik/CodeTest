package codechallenge.writer;

import codechallenge.enums.WriteOperation;
import codechallenge.writer.impl.FileWriter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class FileWriterTest {

    @InjectMocks
    FileWriter fileWriter;

    @Test
    public void testPrintAfterWriteToFile() {
        fileWriter.write("This is is it", WriteOperation.DUPLICATE_REMOVER, WriteOperation.TO_UPPER_CASE);
        fileWriter.print();
    }

    @Test
    public void testWriteToFileAfterClose() {
        fileWriter.close();
        fileWriter.write("This is is it stupid", WriteOperation.DUPLICATE_REMOVER, WriteOperation.STUPID_REMOVER);
        fileWriter.print();
    }
}
