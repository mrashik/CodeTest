package codechallenge.operation;


import codechallenge.writer.WriteOptions;

/**
 * @author muhammedrashik
 **/
public class LowerCaseOperation implements WriteOptions {

    private static LowerCaseOperation instance = null;

    private LowerCaseOperation(){

    }

    public static LowerCaseOperation TO_LOWER_CASE(){
        if (instance == null)
            instance = new LowerCaseOperation();
        return  instance;
    }

    @Override
    public String action(String stringToBeTransformed) {
        return stringToBeTransformed.toLowerCase();
    }

}
