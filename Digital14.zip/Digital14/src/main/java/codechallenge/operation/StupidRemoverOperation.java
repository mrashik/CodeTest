package codechallenge.operation;

import codechallenge.writer.WriteOptions;

/**
 * @author muhammedrashik
 */
public class StupidRemoverOperation implements WriteOptions {

    private static StupidRemoverOperation instance = null;

    private StupidRemoverOperation(){

    }

    public static StupidRemoverOperation STUPID_REMOVER() {
        if (instance == null)
            instance = new StupidRemoverOperation();
        return  instance;
    }

    @Override
    public String action(String stringToBeTransformed) {
        if(stringToBeTransformed.contains("stupid")) {
             return stringToBeTransformed.replace("stupid", "s*****");
        }
        return stringToBeTransformed;
    }

}
