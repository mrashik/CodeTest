package codechallenge.operation;

import codechallenge.writer.WriteOptions;

/**
 * @author muhammedrashik
 */
public class UpperCaseOperation implements WriteOptions {

    private static UpperCaseOperation instance = null;

    private UpperCaseOperation(){

    }

    public static UpperCaseOperation TO_UPPER_CASE(){
        if (instance == null)
            instance = new UpperCaseOperation();
        return  instance;
    }

    @Override
    public String action(String stringToBeTransformed) {
        return stringToBeTransformed.toUpperCase();
    }
}
