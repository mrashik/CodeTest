package codechallenge.operation;

import codechallenge.writer.WriteOptions;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicReference;

public class DuplicateRemoverOperation implements WriteOptions {

    private static DuplicateRemoverOperation instance = null;

    private DuplicateRemoverOperation(){
    }

    public static DuplicateRemoverOperation DUPLICATE_REMOVER(){
        if (instance == null)
            instance = new DuplicateRemoverOperation();
        return  instance;
    }

    @Override
    public String action(String stringToBeTransformed) {
        AtomicReference<String> result = new AtomicReference<>("");
        String allWords[];
        allWords = stringToBeTransformed.split(" ");
        LinkedHashSet<String> set = new LinkedHashSet<String>( Arrays.asList(allWords));
        set.stream().forEach(word -> {
            result.set(result + word + " ");
        });
        return result.get();
    }

}
