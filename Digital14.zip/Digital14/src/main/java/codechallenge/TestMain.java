package codechallenge;

import codechallenge.enums.WriteOperation;
import codechallenge.writer.impl.FileWriter;
import codechallenge.writer.impl.StringWriter;

/**
 * @author muhammedrashik
 **/
public class TestMain {

    public static void main(String[] args){

        StringWriter stringWriter = new StringWriter();
        FileWriter fileWriter = new FileWriter();
        stringWriter.write("This is is it stupid", WriteOperation.TO_LOWER_CASE, WriteOperation.DUPLICATE_REMOVER, WriteOperation.STUPID_REMOVER);
        stringWriter.print();
        fileWriter.write("This is is it stupid", WriteOperation.TO_LOWER_CASE, WriteOperation.DUPLICATE_REMOVER, WriteOperation.STUPID_REMOVER);
        fileWriter.print();
    }
}
