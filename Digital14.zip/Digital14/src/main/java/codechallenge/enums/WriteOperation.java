package codechallenge.enums;


import codechallenge.operation.DuplicateRemoverOperation;
import codechallenge.operation.LowerCaseOperation;
import codechallenge.operation.StupidRemoverOperation;
import codechallenge.operation.UpperCaseOperation;
import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public enum WriteOperation {

    TO_LOWER_CASE(LowerCaseOperation.TO_LOWER_CASE()),
    TO_UPPER_CASE(UpperCaseOperation.TO_UPPER_CASE()),
    STUPID_REMOVER(StupidRemoverOperation.STUPID_REMOVER()),
    DUPLICATE_REMOVER(DuplicateRemoverOperation.DUPLICATE_REMOVER());

    private final codechallenge.writer.WriteOptions value;

}
