package codechallenge.writer.impl;


import codechallenge.enums.WriteOperation;
import codechallenge.writer.Writer;

/**
 * @author muhammedrashik
 **/
public class StringWriter implements Writer {

    private static String  content = null;

    private boolean isOpen = true;

    @Override
    public boolean write(String stringToWrite, WriteOperation... writeOperations) {
        if (isOpen)
            content = WriteOperationHelper.applyOperation(stringToWrite, writeOperations);
        return isOpen;
    }

    @Override
    public void close() {
        isOpen = false;
    }

    @Override
    public void print() {
       System.out.println(content);
    }
}
