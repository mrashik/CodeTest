package codechallenge.writer.impl;

import codechallenge.enums.WriteOperation;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

public class WriteOperationHelper {

    public static String applyOperation(String stringToWrite, WriteOperation... writeOperations) {
        if (null != writeOperations && writeOperations.length != 0) {
            AtomicReference<String> str1 = new AtomicReference<>(stringToWrite);
            Arrays.stream(writeOperations)
                    .forEach(option -> {
                                str1.set(option.getValue().action(str1.get()));
                            }
                    );
            return str1.get().trim();
        }
        return stringToWrite;
    }
}
