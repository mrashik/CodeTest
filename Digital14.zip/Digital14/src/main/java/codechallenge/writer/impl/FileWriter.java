package codechallenge.writer.impl;

import codechallenge.enums.WriteOperation;
import codechallenge.writer.Writer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * @author muhammedrashik
 */
public class FileWriter implements Writer {

    private boolean isOpen = true;
    private final String FILE_NAME = "myfile.dat";

    @Override
    public boolean write(String stringToWrite, WriteOperation... writeOperations)  {

        if (isOpen) {
            String   finalString = WriteOperationHelper.applyOperation(stringToWrite, writeOperations);
            FileOutputStream outputStream = null;
            try {
                outputStream = new FileOutputStream(FILE_NAME);
                byte[] strToBytes = finalString.getBytes();
                outputStream.write(strToBytes);
            }
            catch (IOException e) {
                System.out.print(e.getMessage());
            }
            finally {
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    }
                    catch (IOException e) {
                        System.out.print(e.getMessage());
                    }
                }
            }
        }
        return isOpen;

    }

    @Override
    public void close() {
        isOpen = false;
    }

    @Override
    public void print() {
        FileInputStream inputStream = null;
        try {
            inputStream = new FileInputStream(FILE_NAME);
            int content;
            while ((content = inputStream.read()) != -1) {
                System.out.print((char) content);
            }
        }
        catch (IOException e) {
            System.out.print(e.getMessage());
        }
        finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                }
                catch (IOException e) {
                    System.out.print(e.getMessage());
                }
            }
        }
    }


}
