package codechallenge.writer;

public interface WriteOptions {

    String action(String stringToBeTransformed);
}
