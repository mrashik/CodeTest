package codechallenge.writer;


import codechallenge.enums.WriteOperation;

public interface Writer {

    boolean write(String stringToWrite, WriteOperation... writeOperations);

    void close();

    void print();
}
