#This project provides the functionality  for users to write content to String/File and print the Content. In addition users will have options to choose available operations modify the content before writes.

##Programming language
Java 1.8

### Design Patten
Facade & Decorator Pattern (more loose coupling)

###How to run the project
Run TestMain.java file